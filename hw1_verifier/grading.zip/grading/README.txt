First, run `make' to generate `testing'.
Then, run `python3 grading.py [your_program]'.
